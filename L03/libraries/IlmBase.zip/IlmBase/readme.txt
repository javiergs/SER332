***********************************************
***********************************************
*                                             *
*	Vector library & Obj file loader      *
*                                             *
*                                             *
***********************************************
***********************************************

[Vector Library Compile & Usage]

 - Windows (Visual Studio):
1. In project property dialog, add following Include Directories
		
		.\ilmbase\inc\half, .\ilmbase\inc\ilmthread, .\ilmbase\inc\iex, .\ilmbase\inc\imath

2. In project property dialog, add Library Directory

3. Include corresponding header files, ex.
		#include "imathvec.h"


